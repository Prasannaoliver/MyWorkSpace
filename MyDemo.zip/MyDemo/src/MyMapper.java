import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class MyMapper extends Mapper<LongWritable,Text,IntWritable,IntWritable> {

	public void map(LongWritable inpk,Iterable<Text> inpv,Context c) throws IOException, InterruptedException{
		
		String data=inpv.toString();
		String[] values=data.split(",");
		int id=Integer.parseInt(values[0]);
		
		c.write(new IntWritable(id),new IntWritable(1));
		
	}
	
	
}
