import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;


public class MyReducer extends Reducer<IntWritable,IntWritable,Text,IntWritable> {

	public void reduce(Iterable<IntWritable> rInpKey, Iterable<IntWritable> rInpVal, Context c) throws IOException, InterruptedException{
	
		int count=0;
		for(IntWritable x:rInpKey){
			count=count+1;
		}
		c.write(null, new IntWritable(count));
	}
	
}
