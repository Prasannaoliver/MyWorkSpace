import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;


public class MyReducer extends Reducer<Text, Text, Text, Text> {
	public void reduce(Text inpK, Iterable<Text> inpV, Context c) throws IOException, InterruptedException{
		String name=null,Topic=null;
		for(Text each:inpV){
			String[] data=each.toString().split(":");
			if(data[0].equals("name"))
				name=data[1];
			if(data[0].equals("Topics"))
				Topic=data[1];
			String[] key=inpK.toString().split(":");
			if(name!=null & Topic!=null)
			c.write(new Text(key[1]), new Text(" "+name+" "+Topic));
			}
		
				
		
	}

}
