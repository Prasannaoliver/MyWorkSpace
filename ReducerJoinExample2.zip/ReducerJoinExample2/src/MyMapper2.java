import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Mapper.Context;

public class MyMapper2 extends Mapper<LongWritable, Text, Text, Text>{
	public void map(LongWritable inpK, Text inpV, Context c) throws IOException, InterruptedException{
		String eachVal[] =inpV.toString().split(",");
		c.write(new Text("id:"+eachVal[1]), new Text("Topics:"+eachVal[2]));
	}

}
