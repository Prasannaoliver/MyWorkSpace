import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class MyMapper extends Mapper<LongWritable,Text,Text,IntWritable>{

	public void reduce(LongWritable k,Text v,Context c) throws IOException, InterruptedException{
		String data=v.toString();
		String[] values=data.split(",");
		Text dept=new Text(values[2]);
		
		c.write(dept,new IntWritable(1));
	}
	
}
