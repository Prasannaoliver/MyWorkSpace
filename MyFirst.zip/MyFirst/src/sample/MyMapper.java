package sample;

import java.io.IOException;
import java.util.StringTokenizer;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class MyMapper extends Mapper<LongWritable,Text,IntWritable,IntWritable> {

public void map(LongWritable inpk,Text inpv,Context c) throws IOException, InterruptedException{
	String data=inpv.toString();
	String[] val=data.split(",");
	int id=Integer.parseInt(val[0]);
	
	
	c.write(new IntWritable(1),new IntWritable(1));
	
}
	
}
