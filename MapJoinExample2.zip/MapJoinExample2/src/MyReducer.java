import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.Reducer.Context;

public class MyReducer extends Reducer<Text,Text, Text, Text> {
	public void reduce(Text rInpKey, Iterable<Text> rInpVal,Context c ) throws IOException, InterruptedException{
		String name=null,topics=null;
		for(Text each: rInpVal){
		String[] data=each.toString().split(":");
		name=data[0];
		topics=data[1];
		c.write(rInpKey, new Text(name+":"+topics));
			}
		
		
	}

}
