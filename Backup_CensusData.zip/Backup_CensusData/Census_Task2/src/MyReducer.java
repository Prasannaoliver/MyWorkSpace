import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class MyReducer extends Reducer<Text, Text, Text, Text> {
	public void reduce(Text rInpKey, Iterable<Text> rInpVal, Context c) throws IOException, InterruptedException{
	int fCount = 0;
	int mCount = 0;
	for(Text eachVal: rInpVal){
		if(eachVal.toString().equals(" \" Female\""))
			fCount++;
		if(eachVal.toString().equals(" \" Male\""))
			mCount++;
		}
		String sexRatio = fCount +" : "+mCount;
		Text rOutKey = new Text("For the age group " + rInpKey);
		Text rOutVal = new Text(" the sex ratio is " +sexRatio);
		c.write(rOutKey,rOutVal);

	}
	
}
