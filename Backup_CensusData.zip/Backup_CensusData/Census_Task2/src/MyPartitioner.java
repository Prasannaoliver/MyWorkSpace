import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Partitioner;

public class MyPartitioner extends Partitioner<Text,Text>{

	@Override
	public int getPartition(Text pInpKey, Text pInpVal, int arg2) {
		// TODO Auto-generated method stub
		String s = pInpKey.toString();
		if(s.equalsIgnoreCase("Teenager"))
			return 0;
		else if(s.equalsIgnoreCase("adult"))
			return 1;
		else if(s.equalsIgnoreCase("elderly"))
			return 2;
		else if(s.equalsIgnoreCase("infants"))
			return 3;
		else if(s.equalsIgnoreCase("middle-aged"))
			return 4;
		else if(s.equalsIgnoreCase("senior citizen"))
			return 5;
		else 
			return 0;
	}

}
