

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class MyReducer extends Reducer<Text, Text, Text, Text> {
	public void reduce(Text rInpKey, Iterable<Text> rInpVal, Context c) throws IOException, InterruptedException{
	double totalSal = 0;
	int count = 0;
	for(Text eachVal: rInpVal){
		totalSal+=Double.parseDouble(eachVal.toString());
		count++;
		}
	double avgSal=totalSal/count;
	Text rOutKey = new Text("For the age group " + rInpKey);
	Text rOutVal = new Text(" the average salary is " +avgSal);
	c.write(rOutKey,rOutVal);

	}
	
}
