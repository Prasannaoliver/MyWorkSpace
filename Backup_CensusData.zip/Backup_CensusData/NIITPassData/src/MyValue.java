import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;

public class MyValue implements Writable{
	Text grade;
	
	public MyValue(){
		this.grade = new Text();
	}
	public MyValue(Text grade){
		this.grade=grade;
	};
	
	@Override
	public void readFields(DataInput arg0) throws IOException {
	     grade.readFields(arg0);
	}

	@Override
	public void write(DataOutput arg0) throws IOException {
		grade.write(arg0);
	}
	
	public void setGrade(Text grade){
		this.grade=grade;
	}
	public Text getGrade(){
		return grade;
	}

}