
import java.io.IOException;


import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;



public class MyMapper extends Mapper<MyKey, MyValue, Text, Text> {
	
	public void map(MyKey inpK, MyValue inpV, Context c) throws IOException, InterruptedException{
		int val = c.getConfiguration().getInt("c",0);
		String citizen=inpK.getCitizen();
		int ccode=inpV.getAmt();
		
		if(val==1 && ccode>0 && citizen.trim().equals("Native- Born in the United States"))
			c.write(new Text(citizen),new Text("1"));
		
		if(val==2 && ccode>0 && !citizen.trim().equals("Native- Born in the United States"))
		    c.write(new Text(citizen),new Text("1"));
		
		
		
	}
}

