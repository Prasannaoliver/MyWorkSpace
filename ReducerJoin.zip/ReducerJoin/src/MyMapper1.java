import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class MyMapper1 extends Mapper<LongWritable, Text, Text, Text>{
	public void map(LongWritable inpK, Text inpV, Context c) throws IOException, InterruptedException{
		String eachVal[] =inpV.toString().split(" ");
		c.write(new Text("id:"+eachVal[0]), new Text("name:"+eachVal[1]));
	}

}
