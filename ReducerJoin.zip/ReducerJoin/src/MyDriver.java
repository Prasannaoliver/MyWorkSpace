import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.MultipleInputs;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class MyDriver {

	public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException {
		Job j = new Job(new Configuration(),"Reduce Side Join");
		j.setJarByClass(MyDriver.class);
		j.setReducerClass(MyReducer.class);
		j.setNumReduceTasks(1);
		j.setMapOutputKeyClass(Text.class);
		j.setMapOutputValueClass(Text.class);
		
		MultipleInputs.addInputPath(j, new Path(args[0]), TextInputFormat.class, MyMapper1.class);
		MultipleInputs.addInputPath(j, new Path(args[1]), TextInputFormat.class, MyMapper2.class); 
		
		FileOutputFormat.setOutputPath(j, new Path(args[2]));
		
		System.exit(j.waitForCompletion(true)?0:1);
	}

}
