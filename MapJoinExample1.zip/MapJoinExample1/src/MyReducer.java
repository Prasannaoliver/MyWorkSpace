import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;



public class MyReducer extends Reducer<Text,Text, Text, Text> {
	public void reduce(Text rInpKey, Iterable<Text> rInpVal,Context c ) throws IOException, InterruptedException{
		double amt=0.0;
		for(Text each: rInpVal){
			amt=amt+Double.parseDouble(each.toString());
			}
		c.write(rInpKey, new Text(" Amount:"+amt));
		
	}

}